<p align="center"><a href="https://t.me/useratorsup"><img src="https://telegra.ph/file/1bb657724f15165f795b3.jpg" width="5000"></a></p> 
<h1 align="center"><b>U S Σ R Δ T O R</b></h1>
<h3 align="center">Userator, Telegram işlətməyinizi asandlaşdıran bir botdur. Tamamilə açıq qaynağlı və ödənişsizdir.</h3>
<h3 align="center">Userator is a bot that makes it easy to use Telegram. Completely open source and free.</h3>

## Kömək / Support

<a href="https://t.me/snoxy"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>

<a href="https://t.me/snoxy"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

## Qurulum / Method

<a href="https://youtu.be/fBBJoU1uV-w"><img src="https://static.wikia.nocookie.net/logopedia/images/9/90/YouTube_logo_2005.svg/revision/latest/scale-to-width-down/340?cb=20160807125041"></a>

**Android üçün:** Termuxu açın bu kodu yapışdırın: `bash <(curl -L https://git.io/JkrSb)`

**iOS üçün:** iSH açın bu kodu yapışdırın: `apk update && apk add bash && apk add curl && curl -L -o dto_installer.sh https://git.io/Jkr9n && chmod +x dto_installer.sh && bash dto_installer.sh`


### Heroku ilə deploy / Deploying To Heroku

[![DEAKTİFy]

## Məlumat / Info
<h5 align="center">Botun yanlış istifadəsi halında məsuliyyət tamamilə istifadəçiyə
aiddir.Userator idarəçiləri olaraq heç bir məsuliyyət qəbul etmirik.
Botu telegramı daha rahat istifadə eləmək xaricində əylənmək
üçün də istifadə edə bilərsiniz.</h5>

### Lisenziya / License

<a href="https://tr.m.wikipedia.org/wiki/MIT_Lisans%C4%B1"><img src="https://upload.wikimedia.org/wikipedia/commons/0/0c/MIT_logo.svg"></a>

## Yaradıcı / Creator

[SNOXY](https://t.me/snoxy)

## Təşəkkürlər / Thanks 

[Hüseyn Abbasov](https://t.me/hus3yns)

[BristolMyers](http://t.me/BristolMyers)
